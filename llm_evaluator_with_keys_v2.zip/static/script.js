const socket = io();

function sendQuery() {
    const query = document.getElementById('userQuery').value;
    fetch('/query', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({query: query})
    }).then(response => response.json())
      .then(data => console.log('Response from /query:', data))
      .catch(error => console.error('Error:', error));
}

socket.on('response', function(data) {
    console.log('Received data from WebSocket:', data);
    const responsesDiv = document.getElementById('responses');
    responsesDiv.innerHTML = JSON.stringify(data, null, 2);
});
