from flask import Flask, request, jsonify, render_template
from flask_socketio import SocketIO
import openai
import replicate
import pinecone
import json

app = Flask(__name__)
socketio = SocketIO(app)

# Initialize OpenAI and Replicate API keys
openai.api_key = "sk-proj-1xgneebxIVJrLGK3fsogT3BlbkFJPCtsjxDtgZxYbcD7qzCo"
replicate.api_token = "r8_cvE61JdMJ2iPu9iXo7DRdOqtGfWlbh323f0oJ"
pinecone.init(api_key="019f7b6b-9816-4d24-a18a-7e3ea5430fda")
index = pinecone.Index("web-content")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/query', methods=['POST'])
def handle_query():
    user_query = request.json.get('query')
    
    # Retrieve search results from Pinecone
    search_results = index.query(user_query, top_k=5)['matches']
    combined_results = "\n\n".join([result['metadata']['text'] for result in search_results])
    
    # Construct prompt for LLMs
    combined_prompt = f"Search results:\n{combined_results}\n\nUser query:\n{user_query}"
    
    # Query LLMs
    responses = query_llms(combined_prompt)
    
    # Evaluate responses
    evaluation = evaluate_responses(responses)
    
    # Emit results to frontend
    socketio.emit('response', {'responses': responses, 'evaluation': evaluation})
    
    return jsonify({"status": "success"})

def query_llms(prompt):
    response_gpt35 = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}]
    ).choices[0].message['content']

    response_gpt4 = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}]
    ).choices[0].message['content']

    response_llama = replicate.run(
        "replicate/llama-2-70b-chat",
        input={"prompt": prompt}
    )

    response_falcon = replicate.run(
        "joehoover/falcon-40b-instruct",
        input={"prompt": prompt}
    )

    return {
        "gpt-3.5-turbo": response_gpt35,
        "gpt-4": response_gpt4,
        "llama-2-70b-chat": response_llama,
        "falcon-40b-instruct": response_falcon
    }

def evaluate_responses(responses):
    keyword = "specific_keyword"
    scores = {}
    for model, response in responses.items():
        score = response.lower().count(keyword)
        scores[model] = score
    return scores

if __name__ == '__main__':
    socketio.run(app, debug=True)
