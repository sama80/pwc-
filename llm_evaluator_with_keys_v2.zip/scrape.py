import requests
from bs4 import BeautifulSoup

def scrape_website(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')
    return soup.get_text()

def get_all_links(base_url):
    response = requests.get(base_url)
    soup = BeautifulSoup(response.text, 'html.parser')
    links = [a['href'] for a in soup.find_all('a', href=True) if a['href'].startswith(base_url)]
    return links

base_url = "https://u.ae/en/information-and-services"
all_links = get_all_links(base_url)
all_content = {link: scrape_website(link) for link in all_links}

import pinecone
pinecone.init(api_key="019f7b6b-9816-4d24-a18a-7e3ea5430fda")
index = pinecone.Index("web-content")

for url, content in all_content.items():
    index.upsert(vectors=[{
        'id': url,
        'values': content.split(),
        'metadata': {'url': url, 'text': content}
    }])
